                         Government of British Columbia

                             Oil and Gas Commission



                         ===============================



NOTE: The zone_prd.csv file has been split into additional files due to size limitations.

      This will allow the files to be more easily accessed by spreadsheet programs.

  

The following production related files are included in this .Zip



File                                    Description

-----------                             -----------

zone_prd.csv                            Contains all production records

zone_prd_1954_to_2006.csv               Contains historical records from 1954 to 2006

zone_prd_2007_to_2015.csv               Contains records from 2007 to 2015

zone_prd_2016_to_present.csv            Contains records from 2016 to present






If you have any questions or concerns please feel free to contact the BCOGC service desk OGC.Systems@bcogc.ca

